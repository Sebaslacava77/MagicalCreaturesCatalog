//Exercise 1
struct Creature {
    let name: String
    let description: String
    let isGood: Bool
    let magicPower: Int
}

let leprechaun = Creature(name: "leprechaun", description: "A gentle being with luck and gold.", isGood: true, magicPower: 5)
let dragon = Creature(name: "Dragon", description: "A fierce fire-breathing beast.", isGood: false, magicPower: 8)
let phoenix = Creature(name: "Phoenix", description: "A fiery bird that resurrects from ashes.", isGood: true, magicPower: 7)

// Exercise 2
func fibonacciAbility(_ n: Int) -> Int {
    if n <= 1 { return n }
    return fibonacciAbility(n - 1) + fibonacciAbility(n - 2)
}

extension Creature {
    var ability: String {
        let power = fibonacciAbility(magicPower)
        return "This creature channels a power level of \(power) from ancient magic."
    }
}

//Exercise 3
let creatureCatalog = [leprechaun, dragon, phoenix]

func describeCreature(_ creatures: [Creature]) {
    for creature in creatures {
        print("🧙‍♂️ \(creature.name): \(creature.description)")
        print("✨ \(creature.ability)")
        print("Alignment: \(creature.isGood ? "Good" : "Evil")\n")
    }
}

// Exercise 4
extension Creature {
    func interactWith(_ other: Creature) {
        switch (self.isGood, other.isGood) {
        case (true, true):
            print("\(self.name) and \(other.name) share peaceful magic together.")
        case (false, false):
            print("\(self.name) and \(other.name) plot a chaotic alliance.")
        case (true, false), (false, true):
            print("\(self.name) and \(other.name) clash in a magical duel!")
        }
    }
}

func describecreature(_ creatures: [Creature]) {
    for creature in creatures {
        print("🧙‍♂️ \(creature.name): \(creature.description)")
        print("✨ \(creature.ability)")
        print("Alignment: \(creature.isGood ? "Good" : "Evil")\n")
    }

    print("Fire Interactions:")
    for i in 0..<creatures.count {
        for j in (i + 1)..<creatures.count {
            creatures[i].interactWith(creatures[j])
        }
    }
}
describecreature(creatureCatalog)
